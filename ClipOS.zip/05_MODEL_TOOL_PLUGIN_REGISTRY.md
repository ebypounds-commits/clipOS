# Model, Tool, Plugin & Connector Registry

## 1. Model Registry
Agents reference logical aliases, never provider model IDs directly.

Example aliases:
- `reasoning-premium`
- `reasoning-standard`
- `research-fast`
- `vision-premium`
- `vision-standard`
- `caption-lowcost`
- `classification-local`
- `embedding-default`
- `transcription-default`
- `tts-default`
- `coding-agent` (used by the engineering loop, not ordinary content runs)

Each alias has ordered targets with:
- provider;
- actual model/deployment identifier;
- region/endpoint;
- capability flags;
- price metadata;
- max context/output;
- enabled state;
- health score;
- retry/fallback rules;
- data handling classification.

## 2. LLM Gateway
Implement a provider-neutral `AIClient` interface and a routing service. LiteLLM may be deployed as a gateway, but ClipOS must retain its own registry/policy layer so the product can replace the gateway without rewriting domains.

Routing inputs:
- required capabilities;
- agent policy;
- current provider health;
- spend budget;
- expected token volume;
- latency class;
- data sensitivity;
- experiment assignment.

Routing output must record actual provider/model selected for audit and cost attribution.

## 3. Tool Registry
Tool definition fields:
- stable `tool_id`;
- semantic version;
- description;
- JSON input/output schema;
- capabilities exposed;
- risk class;
- required secret refs;
- allowed network destinations;
- timeout;
- retries;
- idempotency support;
- cost model;
- data classification;
- health check;
- enabled state.

## 4. Plugin types
### Native adapter
For critical/high-throughput integrations: YouTube, TikTok, Meta, storage, transcription, major model providers.

### MCP server
For controlled, discoverable tool surfaces where MCP is appropriate. Prefer private/self-hosted MCP for internal systems and hosted MCP only when trust/network policy permits.

### REST/Webhook connector
For ordinary third-party APIs and inbound notifications.

### Operator-installed extension
Future package model. Must be signed/allow-listed before loading in production.

## 5. Initial integration catalog
### AI
OpenAI, Anthropic, Google; optional Azure/Bedrock; local vLLM/Ollama.

### Media
FFmpeg/ffprobe, transcription adapter, TTS adapter, image/video generation adapters, licensed stock-media adapters.

### Discovery
Search provider adapters, RSS/feeds, platform discovery APIs where permitted, manually configured sources, trend-data providers.

### Publishing
YouTube Data API, TikTok Content Posting API, Meta Graph/Instagram publishing capabilities subject to account/app eligibility.

### Business
Affiliate networks, URL shortener/link attribution, email/notification provider, optional Stripe for future SaaS billing.

### Infrastructure
S3-compatible object storage, SMTP/email, error tracking, observability, GitHub/Codex engineering workflow.

## 6. Connector security
- OAuth tokens encrypted at rest via secret manager/ref layer.
- Refresh tokens never logged.
- Scope inventory stored and displayed.
- Connector refuses operation when required scope missing.
- Credential expiry/refresh health monitored.
- Per-account kill switch.
- Webhook signatures verified and replay-protected.

## 7. Tool sandboxing
LLM-facing code/shell tools must run inside constrained sandboxes with:
- no host Docker socket;
- no unrestricted host filesystem;
- explicit writable workspace;
- network allowlist;
- CPU/memory/time limits;
- no production secrets unless a narrowly scoped action requires them;
- complete invocation audit.
